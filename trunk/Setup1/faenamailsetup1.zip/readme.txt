Readme.txt
Faena Mail version 1.0.5
 
"Faena Mail" is an easy to use desktop email processor for small business and personal use. Handles professional messaging automatically. 
"Faena Mail" can automatically send dynamic response messages to your incoming e-mail, parse the data in the e-mail messages, send custom outgoing e-mails on schedule, and more. Use it for personal e-mail, or give your business a professional image..
 
 
Installation:
Extract and run the FaenaMailSetup.msi from the ZIP file. Follow the screen install instructions. See http://www.faena.com/FaenaMail for step by step tour.


System Requirement:
Windows 98/Me/NT4/2000/XP
Microsoft .NET Framework 1.0
Microsoft Windows Installer


DISCLAIMER - AGREEMENT:
Users of 'Faena Mail' must accept this disclaimer of warranty:

"'Faena Mail' is supplied as is."

The author disclaims all warranties, expressed or implied, including, without limitation, the warranties of merchantability and of fitness for any purpose.

The author assumes no liability for damages, direct or consequential, which may result from the use of 'Faena Mail'.

'Faena Mail' is copyrighted (c) 2003 by Faena Technologies. All rights reserved.



Contact Author:
support@faena.com
http://www.faena.com
Copyright(c) 2003 Faena Technologies